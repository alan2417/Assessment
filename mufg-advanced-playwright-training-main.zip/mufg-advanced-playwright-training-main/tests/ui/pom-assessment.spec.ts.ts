import {test, expect} from '@playwright/test';

import {LoginPage} from '../../pages/LoginPage';
import {DashboardPage} from '../../pages/Dashboard';

test('user can log in and see the dashboard', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const dashboardPage = new DashboardPage(page);
  
  await loginPage.goto();
  await loginPage.login( 'demo', 'demo1234');
  await expect(dashboardPage.welcomeHeading).toHaveText('Welcome, demo');
  await expect(dashboardPage.accountBalance).toHaveText('₹1,25,000.50');
});
