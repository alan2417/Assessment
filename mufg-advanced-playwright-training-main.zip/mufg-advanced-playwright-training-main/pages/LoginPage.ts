import { Page, Locator, expect } from '@playwright/test';

/** Login page for the demo "core banking portal" (the-internet.herokuapp.com/login). */
export class LoginPage {
  readonly page: Page;
  readonly Businessarea: Locator;
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly flashMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.Businessarea = page.getByText('Business area');
    this.usernameInput = page.getByLabel('Username');
    this.passwordInput = page.getByLabel('Password');
    this.loginButton = page.getByRole('button', { name: /Log in/i });
    this.flashMessage = page.locator('#flash');
  }

  async goto() {
    await this.page.goto('http://localhost:5173/');
  }

  async login(username: string, password: string) {
    await this.usernameInput.fill(username);
    await this.passwordInput.fill(password);
    await this.loginButton.click();
  }

  async expectError(messageSubstring: string) {
    await expect(this.flashMessage).toContainText(messageSubstring);
  }
}
