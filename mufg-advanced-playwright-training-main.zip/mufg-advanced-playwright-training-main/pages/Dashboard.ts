import { Page, Locator, expect } from '@playwright/test';

export class DashboardPage {
  readonly page: Page;
  readonly welcomeHeading: Locator;
  readonly accountBalance:Locator;

  constructor(page: Page) {
    this.page = page;
    
    this.welcomeHeading=page.getByRole('heading',{name:'Welcome, demo'});
    this.accountBalance=page.getByTestId('account-balance');

  }
    

  
    }